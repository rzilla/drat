stopif = function(x, message) if(x) stop(message)
